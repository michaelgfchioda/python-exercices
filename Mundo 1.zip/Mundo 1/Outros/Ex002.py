nome = input('Olá! Qual é o seu nome? ')
print('Prazer em te conhecer, {}!'.format(nome))
