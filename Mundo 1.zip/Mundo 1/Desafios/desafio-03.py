print('Digite dois números para calcular a soma entre eles: ')
num1 = int(input('Primeiro número: '))
num2 = int(input('Segundo número: '))
soma = num1 + num2
print('A soma é: {}'.format(soma))
