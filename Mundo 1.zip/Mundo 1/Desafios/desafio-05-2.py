# 5. Faça um programa que leia um número inteiro e mostre na tela seu sucessor e seu antecessor

num = int(input('Digite um número inteiro: '))
print('O sucessor desse número é {}'.format(num + 1))
print('O antecessor desse número é {}'.format(num - 1))
# Eu poderia ter atribuído à duas novas variáveis o antecessor e o sucessor,
# o que seria o ideal se eu precisasse delas mais pra frente no programa.
