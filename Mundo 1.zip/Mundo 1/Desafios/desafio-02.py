dia = input('Qual dia você nasceu? ')
mes = input('E o mês? ')
ano = input('Em qual ano? ')

print('Sua data de nascimento é:')
print(dia, '/', mes, '/', ano)
