dia = input('Qual dia você nasceu? ')
mes = input('E o mês? ')
ano = input('Em qual ano? ')

print('Você nasceu dia', dia, 'de', mes, 'de', ano)
