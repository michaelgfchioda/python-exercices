# Desafio 4: Faça um programa em python que leia dois números e mostre a soma entre eles

print('Digite dois números: ')
num1 = int(input('Primeiro número: '))
num2 = int(input('Segundo número: '))
soma = num1 + num2
print('A soma entre os números {} e {} é {}'.format(num1, num2, soma))
