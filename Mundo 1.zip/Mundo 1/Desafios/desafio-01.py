nome = input('Qual é o seu nome? ')
print('Seja bem vindo, {}!'.format(nome))
