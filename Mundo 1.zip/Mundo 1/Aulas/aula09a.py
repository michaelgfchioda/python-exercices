"""FATIAMENTO DE STRINGS"""

frase = 'Curso em Vídeo Python'
'''print(frase[9]) - imprime o caracter no índice 9.

   print(frase[15]) - imprime o caracter no índice 15.
   
   print(frase[9:14]) - imprime os caracteres entre os índices 9 e 14.
   
   print(frase[9:14:2]) - imprime os caracteres entre os índices 9 e 14 de 2 em 2.
   
   print(frase[:8]) - imprime todos os caracteres até o índice 8.
   
   print(frase[8:]) - imprime todos os caracteres a partir do índice 8.
   
   print(frase[9::3]) - imprime, a partir do índice 9, até o final da string de 3 em 3.
   
   print(frase[::2] - imprime desde o índice 0(não sei o começo e nem o final da string) até o final da string de 2 em 2
'''
