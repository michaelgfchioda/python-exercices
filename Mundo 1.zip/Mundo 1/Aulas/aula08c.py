# É possível definir dois números inteiros quaisquer, um mínimo e um máximo,
# utilizando a função randint(), para o programa retornar um número inteiro aleatório entre eles,
# ou seja, desde o 1 até o 10 como nesse exemplo:
import random
num = random.randint(1, 10)
print(num)
