# Eu quero saber se a variável guarda um número:
# Exemplo: 1, 2, 3, 4, 5...
# n = input('Digite algo: ')
# print(n.isnumeric())

# Eu quero saber se a variável guarda uma letra do alfabeto
# Exemplo: a, b, c, A, B, C...
# n = input('Digite algo: ')
# print(n.isalpha())

# Eu quero saber se a variável guarda tanto um número quanto uma letra do alfabeto
# Exemplo: 7, a, A, 18, c, D, 5mm...
# n = input('Digite algo: ')
# print(n.isalnum())
