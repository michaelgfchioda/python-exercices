import math
num1 = int(input('Digite um número: '))
raiz = math.sqrt(num1)
print('A raiz quadrada de {} é {}'.format(num1, math.ceil(raiz)))

# from math import sqrt
# num1 = int(input('Digite um número: '))
# print('A raiz quadrada de {} é {:.0f}'.format(num1, sqrt(num1)))
