frase = 'Curso em Vídeo Python'
frase = frase.split()
print(frase[3][1])
