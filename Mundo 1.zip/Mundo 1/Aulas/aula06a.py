print('Digite dois números para soma: ')
num1 = int(input('Primeiro número: '))
num2 = int(input('Segundo número: '))
soma = num1 + num2
# print('A soma entre', num1, 'e', num2, 'é: ', soma)
print('A soma entre {} e {} é {}'.format(num1, num2, soma))
