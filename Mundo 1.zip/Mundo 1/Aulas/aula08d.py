import emoji
print(emoji.emojize('Good morning :smiling_face_with_sunglasses:'))

# Para utilizar os emojis dessa biblioteca, como o ":smiling_face_with_sunglasses:",
# acesse o site https://pypi.org/project/emoji/#description e
# clique no link "Emoji Cheat Sheet" para consultar os códigos de cada um,
# ou acesse diretamente pelo link: https://www.webfx.com/tools/emoji-cheat-sheet/#
