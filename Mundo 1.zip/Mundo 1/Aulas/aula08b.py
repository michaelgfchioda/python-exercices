# Utilizando a função random() dessa forma, por padrão, ao executar,
# o programa sempre retonará um número aleatório entre 0 e 1,
# ou seja, números com pontos flutuantes
import random
num = random.random()
print(num)
